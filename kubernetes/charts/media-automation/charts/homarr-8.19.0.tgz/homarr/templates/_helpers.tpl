{{/*
Expand the name of the chart.
*/}}
{{- define "homarr.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "homarr.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "homarr.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Validate .Values.strategyType
*/}}
{{- define "homarr.validatedStrategyType" -}}
{{- $strategy := .Values.strategyType | default "RollingUpdate" -}}
{{- if or (eq $strategy "RollingUpdate") (eq $strategy "Recreate") -}}
  {{- $strategy -}}
{{- else -}}
  {{- printf "RollingUpdate" -}}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "homarr.labels" -}}
helm.sh/chart: {{ include "homarr.chart" . }}
{{ include "homarr.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "homarr.selectorLabels" -}}
app.kubernetes.io/name: {{ include "homarr.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "homarr.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "homarr.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
